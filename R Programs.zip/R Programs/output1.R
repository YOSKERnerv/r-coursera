{print("hello")
var1=10
print(var1)
cat(var1)
var2<-20
var3<-30
cat(var1,var2)
cat(var1," ",var2,"\n",var3)
}
print(ls())

