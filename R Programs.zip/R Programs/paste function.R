a<-"hello"
print(paste("how are you",a))
print(paste0("how are you",a))
sprintf("Welcome to %s",a)
b<-5.6
c<-'A'

