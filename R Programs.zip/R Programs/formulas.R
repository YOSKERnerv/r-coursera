#Formulas
#you need to express a relationship between variables
sample.formula<-as.formula(y~a+b+c)
sample.formula
#This formula means “y is a function of x1, x2, and x3.”
class(sample.formula)
typeof(sample.formula)
