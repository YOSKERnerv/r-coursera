# to get all the object names
#all.names a logical value. If TRUE, all object names are returned. 
#If FALSE, names which begin with a . are omitted.
ls(all.names = TRUE)
#hidden variables will not be visible
ls()
