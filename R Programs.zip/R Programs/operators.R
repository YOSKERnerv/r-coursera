#operators in R
#arithmetic Operators
 a<-7.5
 b<-2
 a+b
 a-b
 a/b
 a*b
 a%%b #remainder
 a%/%b #Quotient
 a^b #exponential
 #vector-collection of similar data types
 c1<-c(7,8,9)
 c2<-c(2,3,4)
 c1+c2
 c1-c2
 c1/c2
 c1*c2
 c1%%c2 #remainder
 c1%/%c2 #Quotient
 c1^c2 #exponential
 #relational Operators < >==<=>=!=
 a<-7.5
 b<-2
 a<b
 a>b
 a<=b
 a>=b
 a==b
 a!=b
 c1<-c(7,8,9)
 c2<-c(2,3,4)
 c1<c2
 c1>c2
 c1<=c2
 c1>=c2
 c1==c2
 c1!=c2
 #logical operators & | ! && ||
 c3<-c(3.5,TRUE,2+5i)
 c4<-c(2.4,TRUE,6+5i)
 c3&c4
c3&&c4 
!c3
print(ls()) 
a<-c(TRUE,TRUE,FALSE)
b<-c(FALSE,TRUE,TRUE)
a&b
a&&b
print(a||b)
v<-c(3,0,TRUE,2+2i)
t<-c(1,3,TRUE,2+3i)
?`&&`
10:100
a<-c(25,26,27)
b<-27
b%in%a
