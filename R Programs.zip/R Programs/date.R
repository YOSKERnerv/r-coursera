date.1<-as.Date("2/13/2009","%m/%d/%Y")
date.1
today<-Sys.Date()
today
diff<-today-date.1
diff

