#text mining:is the process of deriving meaningful info 
#from NLP
#millions of data is produced and out of all, 
#21% data is structure,rest is unstructured data
#how to analyse your data correctly
#only way to add value to your business is to extract 
#meaning information from all the data we have
#where it is used:
#autocomplete,spam detection,predicting typing,spell checker
#NLP is a part of computer science and AI which deals with
#human language
#steps:
#Importing data->create a corpus(structured data set(collec of doc))
#->pre-processing(remove tags,
#stop words(common used words),punctuations,numbers,whitespaces,stemming)->
#create Document term matrix(frequency of word occuring in doc 
#->text analysis(Word frequency correlation)->
#text visualistaion(word cloud,histo)
install.packages('tm')

